using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Quit_method : MonoBehaviour
{
  public void quit(){
    Application.Quit();
  }
}
